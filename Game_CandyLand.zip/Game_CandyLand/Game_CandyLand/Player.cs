﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_CandyLand
{
    class Player
    {
        // Position field.
        public int Position;

        // Player Number field.
        public int PlayerNumber;

        // Game Piece field.
        public int GamePiece;

        // Name field.
        public string Name;

        // Stuck field.
        public bool Stuck;

        // DisplayPosition method.

    }
}
