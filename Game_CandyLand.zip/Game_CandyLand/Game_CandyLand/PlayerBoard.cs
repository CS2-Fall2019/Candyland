﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="Triple B & Schulze">
//     Copyright (c) Biles & Schulze. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Game_CandyLand
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    public partial class PlayerBoard : Form
    {
        public PlayerBoard()
        {
            InitializeComponent();
        }

    }
}
